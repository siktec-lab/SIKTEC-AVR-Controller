# SIKTEC-AVR-Controller, *Example Images*
Copy those images to the SD card - The "Image Scanner" Example will detect them and draw them in the menu and on the screen.

### Notes
Some addition notes on file types - naming - ext.
1. note 
2. note
3. note